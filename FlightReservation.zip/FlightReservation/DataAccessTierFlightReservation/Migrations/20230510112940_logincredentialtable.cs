﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataAccessTierFlightReservation.Migrations
{
    /// <inheritdoc />
    public partial class logincredentialtable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LoginCredentials",
                columns: table => new
                {
                    UserID = table.Column<int>(type: "int", nullable: false),
                    UserType = table.Column<string>(type: "nvarchar(1)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LoginCredentials");
        }
    }
}
