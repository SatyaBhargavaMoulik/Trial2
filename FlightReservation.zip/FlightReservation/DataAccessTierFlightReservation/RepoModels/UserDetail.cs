﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace DataAccessTierFlightReservation.RepoModels
{
    [Table("UserDetails")]
    public class UserDetail
    {
        [Key]
        public int UserID { get; set; }

        [Required(ErrorMessage ="Password is Required")]
        [MinLength(6,ErrorMessage ="Password is too short"),MaxLength(20,ErrorMessage ="Maximum length of Password is 20 characters ")]
        [RegularExpression(@"[a-z]+[A-Z]+[!@#$%^&*()_][0-9]+",ErrorMessage ="Invalid Password Format\n It must contains one Capital letter,atleat one numeric digit and one specila character")]
        public string Password { get; set; }

        [Required(ErrorMessage ="First Name is Manditory")]
        [RegularExpression(@"[a-zA-Z]+", ErrorMessage = "Invalid First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is Manditory")]
        [RegularExpression(@"[A-Za-z]+",ErrorMessage ="Invalid Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Date of Birth is Manditory")]
        [DataType(DataType.DateTime)]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage ="Please Enter Age ")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Mention Your Gender")]
        [RegularExpression(@"[A-Za-z]+", ErrorMessage = "Invalid Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Mention Your Address")]
        [StringLength(50,ErrorMessage ="Maximum allowed characters are 50")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Enter Your Mobile Number")]
        [RegularExpression(@"^+[0-9]{2,3}[-][0-9]{10}", ErrorMessage = "Enter Your Mobile Number in +(countrycode-mobile number")]
        public string PhoneNo { get; set; }
        public int LoginStatus { get; set; }

    }
}
