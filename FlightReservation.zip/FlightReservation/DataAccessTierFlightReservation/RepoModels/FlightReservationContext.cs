﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace DataAccessTierFlightReservation.RepoModels
{
    public class FlightReservationContext:DbContext
    {
        DbSet<UserDetail> UsersData { get; set; }
        DbSet<CreditCardDetail> UserCreditCard { get; set; }
        DbSet<LoginCredentials> UsersLoginCredentialList { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DOTNET;Database=FlightReservation;Integrated Security=True;TrustServerCertificate=True;");
            }
            base.OnConfiguring(optionsBuilder);
        }
    }
}
