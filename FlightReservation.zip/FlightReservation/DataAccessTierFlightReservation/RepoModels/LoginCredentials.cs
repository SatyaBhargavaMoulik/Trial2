﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccessTierFlightReservation.RepoModels
{
    [Table("LoginCredentials")]
    [Keyless]
    public class LoginCredentials
    {
        [Required(ErrorMessage ="User ID is required to login")]
        public int UserID { get; set; }

        [Required(ErrorMessage ="User type is required A(admin)/U(user)")]
        [RegularExpression(@"[A,U]",ErrorMessage ="")]

        public char UserType { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [MinLength(6, ErrorMessage = "Password is too short"), MaxLength(20, ErrorMessage = "Maximum length of Password is 20 characters ")]
        [RegularExpression(@"[a-z]+[A-Z]+[!@#$%^&*()_][0-9]+", ErrorMessage = "Invalid Password Format\n It must contains one Capital letter,atleat one numeric digit and one specila character")]
        public string Password { get; set; }


    }
}
