﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccessTierFlightReservation.RepoModels
{
    [Keyless]
    [Table("CreditCardDetails")]
    public class CreditCardDetail
    {
        [Required(ErrorMessage = "CreditCard Number is Required")]
        [MinLength(12,ErrorMessage ="Number length should be greater than 11"),MaxLength(16,ErrorMessage = "Number length should be lesser than 17")]
        [RegularExpression(@"[0-9]{12,16}")]
        public string CreditCardNumber { get; set; }

        [Required(ErrorMessage = "Validity From  is Mandatory")]
        [DataType(DataType.DateTime)]
        public DateTime ValidFrom { get; set; }

        [Required(ErrorMessage = "Validity To  is Mandatory")]
        [DataType(DataType.DateTime)]
        public DateTime ValidTo { get; set; }

        [Required(ErrorMessage = "Please Enter the Existing Balance in your account")]
        public int Balance { get; set; }
    }
}
