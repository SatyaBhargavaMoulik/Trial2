﻿namespace FlightReservationSystem_MVC_.Models
{
    public class FlightEdit: Flight
    {

    }
}
